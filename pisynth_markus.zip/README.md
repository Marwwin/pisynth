# pisynth
A synthesizer that generates music using Pisano number series as input
